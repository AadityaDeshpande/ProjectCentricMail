
chmod +x env_setup.sh
to set up your environment for 1st run type command  ./env_setup.sh

this folder contains a caller.py file to be executed
step 1) open terminal in respective folder and type command:$ python3 caller.py

you will get a output in username_final.csv format




