#! /bin/sh
python3 caller.py \
&& python3 auto.py
