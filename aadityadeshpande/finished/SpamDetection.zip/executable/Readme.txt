this folder contains a bash file to be executed
step 1) open terminal in respective folder and type command ./run.sh

you will get a output in csv format m_id and boolean is_spam value

to set up your environment for 1st run type command  ./env_setup.sh
