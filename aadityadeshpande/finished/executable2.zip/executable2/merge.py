import pandas as pd
def mer(username):
 a=pd.read_csv(f"{username}.csv")
 b=pd.read_csv(f"{username}_output.csv")
 b= b.dropna(axis=1)
 merged = a.merge(b,on='m_id')
 merged.to_csv(f"{username}_final.csv",index=False)
