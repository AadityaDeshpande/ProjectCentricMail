from django.apps import AppConfig


class ProjectcentricmailConfig(AppConfig):
    name = 'ProjectCentricMail'
