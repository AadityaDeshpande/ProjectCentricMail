from django.contrib import admin

# Register your models here.
from .models import MessageInfo,ProjectClassify,ProjectNames

admin.site.register(MessageInfo)
admin.site.register(ProjectClassify)
admin.site.register(ProjectNames)
