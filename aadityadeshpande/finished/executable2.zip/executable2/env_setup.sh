#! /bin/sh
sudo apt install git \
&& sudo apt install git --upgrade \
&& sudo apt install python3-pip \
&& sudo apt install --upgrade python3-pip \
&& pip3 install --upgrade google-api-python-client \
&& pip3 install oauth2client \
&& pip3 install --upgrade oauth2client \
&& pip3 install bs4 \
&& pip3 install --upgrade bs4 \
&& pip3 install python-dateutil \
&& pip3 install --upgrade python-dateutil \
&& pip3 install pandas\
&& pip3 install --upgrade pandas
